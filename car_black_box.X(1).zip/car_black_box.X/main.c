  /*
 * File:   main.c
 * Author: AANIL
 *
 * Created on 25 September, 2024, 8:39 AM
 */


#include <xc.h>
#include "main.h"
#include "adc.h"
#include "clcd.h"
#include "Ext_eeprom.h"
#include "matrix_keypad.h"
#include "timer0.h"
#include "i2c.h"
#include "ds1307.h"
#include "uart.h"
extern unsigned char pass[4];
void init_config(void) {
    init_i2c();
	init_ds1307();
    init_clcd();
    init_matrix_keypad();
    init_adc();
    init_uart();
    PEIE=1;
    init_timer0();
    GIE=1;
    for(int i=0;i<4;i++)
    {
        //pass[i]=0;
        pass[i]=read_eeprom(0xc8+i);
    }
    //
}
unsigned char clock_reg[3];
unsigned char time[9];

static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}

char arr[][3] = {"ON", "GR", "GN", "G1", "G2", "G3", "G4", "G5","-c","DL","CL","ST","CP"};
unsigned char speed = 0;
int i,back_i;
unsigned char flag=0;
char main_f, menu_f, key;
char store_flag;
void main(void) {
    init_config();

    
    while (1) {
        /*
         * get the time 
         * based on switch press change the event
         */
        get_time();
        speed = read_adc(CHANNEL4) / 10.33;
        key = read_switches(STATE_CHANGE);
        if (key == MK_SW2) {
            if (i < 7 && flag == 0) {
                i++;
                store_event();
            }
            if (flag) {
                i = 2;
                store_event();
            }

        } else if (key == MK_SW3) {
            if (i > 1 && flag == 0) {
                i--;
                store_event();
            }

            if (flag) {
                i = 2;
                store_event();
            }

        }
        if (key == MK_SW1) {
            i=8;
            //clcd_print(arr[i],LINE2(9));
            flag=1;
            store_event();
        }
        if (main_f == DASHBOARD) {
            dashboard();
        } else if (main_f == PASSWORD) {
            password(key);
        } else if (main_f == MENU) {
            menu(key);
        } else if (main_f == MENU_ENTER) {
            if (menu_f == VIEWLOG) {
                view_log(key);
            } else if (menu_f == DOWNLOADLOG) {
                download_log();
            } else if (menu_f == CLEARLOG) {
                clear_log(key);
            } else if (menu_f == SETTIME) {
                settime(key);
            } else if (menu_f == CHANGEPASS) {
                change_pass(key);
            }
        }
        if(store_flag==0 && i==0 )
        {
            store_event();
        }

    }
    return;
}
